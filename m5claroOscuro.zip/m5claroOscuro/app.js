function claroOscuro() {
  document.querySelector("body").classList.toggle("dark");
}
